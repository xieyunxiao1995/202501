import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../services/storage_service.dart';
import '../../services/project_service.dart';
import '../../utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  late ProjectService _projectService;
  Map<String, dynamic> _statistics = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _initServices();
  }

  Future<void> _initServices() async {
    final prefs = await SharedPreferences.getInstance();
    final storageService = StorageService(prefs);
    _projectService = ProjectService(storageService: storageService);
    await _loadStatistics();
  }

  Future<void> _loadStatistics() async {
    final stats = await _projectService.getStatistics();
    if (mounted) {
      setState(() {
        _statistics = stats;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        title: Text('统计', style: AppTextStyles.headline3),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _buildContent(),
    );
  }

  Widget _buildContent() {
    final totalProjects = _statistics['totalProjects'] as int? ?? 0;
    final completedProjects = _statistics['completedProjects'] as int? ?? 0;
    final inProgressProjects = _statistics['inProgressProjects'] as int? ?? 0;
    final averageProgress = _statistics['averageProgress'] as double? ?? 0.0;
    final damageTypes =
        _statistics['damageTypeDistribution'] as Map<String, int>? ?? {};

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Main stats card
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: AppColors.primaryGradient,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildMainStat(
                      value: totalProjects.toString(),
                      label: '项目总数',
                    ),
                    Container(
                      width: 1,
                      height: 40,
                      color: Colors.white.withAlpha(77),
                    ),
                    _buildMainStat(
                      value: completedProjects.toString(),
                      label: '已完成',
                    ),
                    Container(
                      width: 1,
                      height: 40,
                      color: Colors.white.withAlpha(77),
                    ),
                    _buildMainStat(
                      value: inProgressProjects.toString(),
                      label: '进行中',
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                // Progress ring
                SizedBox(
                  width: 120,
                  height: 120,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 120,
                        height: 120,
                        child: CircularProgressIndicator(
                          value: averageProgress / 100,
                          strokeWidth: 8,
                          backgroundColor: Colors.white.withAlpha(51),
                          valueColor: const AlwaysStoppedAnimation<Color>(
                            Colors.white,
                          ),
                        ),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '${averageProgress.toStringAsFixed(0)}%',
                            style: AppTextStyles.headline2.copyWith(
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            '平均进度',
                            style: AppTextStyles.caption.copyWith(
                              color: Colors.white.withAlpha(204),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Damage type distribution
          if (damageTypes.isNotEmpty) ...[
            Text('损坏类型分布', style: AppTextStyles.labelLarge),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: damageTypes.entries.map((entry) {
                  final percentage = totalProjects > 0
                      ? (entry.value / totalProjects * 100).toStringAsFixed(0)
                      : '0';
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    AppConstants.getDamageTypeLabel(entry.key),
                                    style: AppTextStyles.bodyMedium,
                                  ),
                                  Text(
                                    '$percentage%',
                                    style: AppTextStyles.labelMedium.copyWith(
                                      color: AppColors.primary,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              LinearProgressIndicator(
                                value: double.parse(percentage) / 100,
                                backgroundColor: AppColors.surfaceLight,
                                valueColor: const AlwaysStoppedAnimation<Color>(
                                  AppColors.primary,
                                ),
                                minHeight: 6,
                                borderRadius: BorderRadius.circular(3),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            const SizedBox(height: 24),
          ],

          // Quick stats
          Text('快速统计', style: AppTextStyles.labelLarge),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildQuickStatCard(
                  icon: Icons.check_circle_outline,
                  value: _statistics['totalCompleted']?.toString() ?? '0',
                  label: '总完成数',
                  color: AppColors.success,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildQuickStatCard(
                  icon: Icons.archive_outlined,
                  value: _statistics['archivedProjects']?.toString() ?? '0',
                  label: '已归档',
                  color: AppColors.textSecondary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 40),

          // Empty state message if no projects
          if (totalProjects == 0)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    Icon(
                      Icons.bar_chart_rounded,
                      size: 64,
                      color: AppColors.textLight,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '暂无项目',
                      style: AppTextStyles.headline3.copyWith(
                        color: AppColors.textSecondary,
                      ),
                    ),
                    Text('创建您的第一个修复项目以查看统计', style: AppTextStyles.bodySmall),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMainStat({required String value, required String label}) {
    return Column(
      children: [
        Text(
          value,
          style: AppTextStyles.headline2.copyWith(color: Colors.white),
        ),
        Text(
          label,
          style: AppTextStyles.caption.copyWith(
            color: Colors.white.withAlpha(204),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickStatCard({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 8),
          Text(value, style: AppTextStyles.headline3.copyWith(color: color)),
          Text(
            label,
            style: AppTextStyles.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
