import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../config/app_config.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        title: Text('关于 Orclavitasyn', style: AppTextStyles.headline3),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Logo and name
            Center(
              child: Column(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      gradient: AppColors.goldGradient,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: AppColors.accentGold.withAlpha(77),
                          blurRadius: 20,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                    child: const Icon(
                      Icons.auto_fix_high,
                      color: Colors.white,
                      size: 50,
                    ),
                  ),
                  const SizedBox(height: 20),
                  Text(AppConfig.appName, style: AppTextStyles.headline1),
                  const SizedBox(height: 4),
                  Text(
                    'Version ${AppConfig.appVersion}',
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),

            // Story section
            _buildSection(
              '我们的故事',
              'Orclavitasyn 源于对金缮艺术的深厚热爱，这是一项拥有400年历史的日本传统工艺，用金线修复破碎的陶器。这种哲学认为破损不应被隐藏，而应成为创造更美好事物的契机。',
            ),
            const SizedBox(height: 24),

            _buildSection(
              '名称含义',
              'Orclavitasyn 这个名字融合了代表金、陶土、生命、修复和综合的词根——捕捉了将破碎器物转化为金色艺术的精髓。',
            ),
            const SizedBox(height: 24),

            _buildSection(
              '我们的使命',
              '我们相信每一道裂痕都在讲述一个故事。我们的使命是引导匠人完成金缮之旅，将传统智慧与现代便捷相结合。每一次修复都是对无常与美的冥想。',
            ),
            const SizedBox(height: 24),

            // Values
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppColors.accentGold.withAlpha(51),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '我们的价值观',
                    style: AppTextStyles.labelLarge.copyWith(
                      color: AppColors.accentGold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildValueItem('侘寂之美', '在不完美中发现美'),
                  _buildValueItem('匠心工艺', '尊重传统技艺'),
                  _buildValueItem('可持续发展', '修复而非丢弃'),
                  _buildValueItem('正念修行', '每次修复都是冥想'),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: AppTextStyles.headline3),
        const SizedBox(height: 12),
        Text(
          content,
          style: AppTextStyles.bodyMedium.copyWith(
            color: AppColors.textSecondary,
            height: 1.6,
          ),
        ),
      ],
    );
  }

  Widget _buildValueItem(String title, String description) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(
              color: AppColors.accentGold,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: AppTextStyles.labelLarge),
              Text(description, style: AppTextStyles.bodySmall),
            ],
          ),
        ],
      ),
    );
  }
}
