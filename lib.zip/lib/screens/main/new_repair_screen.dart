import 'dart:io';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../theme/app_decorations.dart';
import '../../models/repair_project.dart';
import '../../services/storage_service.dart';
import '../../services/project_service.dart';
import '../../services/image_service.dart';
import '../../services/ai_service.dart';
import '../../utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class NewRepairScreen extends StatefulWidget {
  const NewRepairScreen({super.key});

  @override
  State<NewRepairScreen> createState() => _NewRepairScreenState();
}

class _NewRepairScreenState extends State<NewRepairScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();

  late ProjectService _projectService;
  late ImageService _imageService;
  late AIService _aiService;

  String? _selectedDamageType = 'crack';
  String? _selectedMaterial = 'stoneware';
  String? _selectedAesthetic = 'classic-gold';
  String? _photoPath;
  bool _isLoading = false;
  bool _isGeneratingNarrative = false;
  String? _generatedNarrative;

  @override
  void initState() {
    super.initState();
    _initServices();
  }

  Future<void> _initServices() async {
    final prefs = await SharedPreferences.getInstance();
    final storageService = StorageService(prefs);
    _projectService = ProjectService(storageService: storageService);
    _imageService = ImageService();
    _aiService = AIService();
  }

  Future<void> _pickFromGallery() async {
    try {
      final file = await _imageService.pickFromGallery();
      if (file != null && mounted) {
        setState(() {
          _photoPath = file.path;
        });
      }
    } catch (e) {
      _showError('Failed to pick photo: $e');
    }
  }

  Future<void> _generateNarrative() async {
    if (_descriptionController.text.isEmpty) {
      _showError('请先描述损坏情况');
      return;
    }

    setState(() {
      _isGeneratingNarrative = true;
    });

    try {
      final narrative = await _aiService.generateCrackNarrative(
        damageType: _selectedDamageType ?? 'crack',
        material: _selectedMaterial ?? 'stoneware',
        aesthetic: _selectedAesthetic ?? 'classic-gold',
        description: _descriptionController.text,
      );

      if (mounted) {
        setState(() {
          _generatedNarrative = narrative;
          _isGeneratingNarrative = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isGeneratingNarrative = false;
        });
        _showError('Failed to generate narrative: $e');
      }
    }
  }

  Future<void> _saveProject() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final project = RepairProject(
        id: const Uuid().v4(),
        title: _titleController.text.isNotEmpty
            ? _titleController.text
            : 'Repair ${DateTime.now().day}/${DateTime.now().month}',
        description: _descriptionController.text,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
        photoPaths: _photoPath != null ? [_photoPath!] : [],
        damageType: _selectedDamageType ?? 'crack',
        material: _selectedMaterial ?? 'stoneware',
        aesthetic: _selectedAesthetic ?? 'classic-gold',
        crackNarrative: _generatedNarrative ?? '',
        techniqueProgress: 0,
        aiRecommendations: [],
        isArchived: false,
      );

      await _projectService.createProject(project);

      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        _showSuccess('项目保存成功');
        _resetForm();
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
        _showError('保存项目失败: $e');
      }
    }
  }

  void _resetForm() {
    _titleController.clear();
    _descriptionController.clear();
    setState(() {
      _photoPath = null;
      _selectedDamageType = 'crack';
      _selectedMaterial = 'stoneware';
      _selectedAesthetic = 'classic-gold';
      _generatedNarrative = null;
    });
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppColors.error),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: AppColors.success),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          behavior: HitTestBehavior.opaque,
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          gradient: AppColors.pinkGradient,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withAlpha(77),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.add_photo_alternate,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 16),
                      Text(
                        '新建修复',
                        style: AppTextStyles.headline1.copyWith(
                          fontSize: 28,
                          color: AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 28),
                  // Photo Section
                  Text('照片', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 12),
                  GestureDetector(
                    onTap: () => _showImageSourceDialog(),
                    child: Container(
                      height: 200,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        gradient: _photoPath == null
                            ? AppColors.pinkGradient
                            : null,
                        borderRadius: BorderRadius.circular(24),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.primary.withAlpha(51),
                            blurRadius: 16,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: _photoPath != null
                          ? ClipRRect(
                              borderRadius: BorderRadius.circular(24),
                              child: Image.file(
                                File(_photoPath!),
                                fit: BoxFit.cover,
                              ),
                            )
                          : Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Container(
                                  width: 64,
                                  height: 64,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withAlpha(51),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.add_a_photo_outlined,
                                    size: 32,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  '点击添加照片',
                                  style: AppTextStyles.bodyMedium.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                  const SizedBox(height: 28),

                  // Title
                  Text('标题（可选）', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _titleController,
                    decoration: AppDecorations.inputDecoration(
                      hintText: '为您的项目命名',
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Description
                  Text('描述', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 8),
                  TextFormField(
                    controller: _descriptionController,
                    maxLines: 3,
                    decoration: AppDecorations.inputDecoration(
                      hintText: '描述损坏情况和修复目标',
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Damage Type
                  Text('损坏类型', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: AppConstants.damageTypes.map((type) {
                      final isSelected = _selectedDamageType == type;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedDamageType = type;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.accentGold.withAlpha(26)
                                : AppColors.surface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected
                                  ? AppColors.accentGold
                                  : AppColors.surfaceLight,
                            ),
                          ),
                          child: Text(
                            AppConstants.getDamageTypeLabel(type),
                            style: AppTextStyles.labelMedium.copyWith(
                              color: isSelected
                                  ? AppColors.accentGold
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // Material
                  Text('陶瓷材质', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: AppConstants.materials.map((material) {
                      final isSelected = _selectedMaterial == material;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedMaterial = material;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.primaryLight.withAlpha(51)
                                : AppColors.surface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected
                                  ? AppColors.primary
                                  : AppColors.surfaceLight,
                            ),
                          ),
                          child: Text(
                            AppConstants.getMaterialLabel(material),
                            style: AppTextStyles.labelMedium.copyWith(
                              color: isSelected
                                  ? AppColors.primary
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),

                  // Aesthetic
                  Text('美学偏好', style: AppTextStyles.labelLarge),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: AppConstants.aesthetics.map((aesthetic) {
                      final isSelected = _selectedAesthetic == aesthetic;
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedAesthetic = aesthetic;
                          });
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 10,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? AppColors.accentGold.withAlpha(26)
                                : AppColors.surface,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isSelected
                                  ? AppColors.accentGold
                                  : AppColors.surfaceLight,
                            ),
                          ),
                          child: Text(
                            AppConstants.getAestheticLabel(aesthetic),
                            style: AppTextStyles.labelMedium.copyWith(
                              color: isSelected
                                  ? AppColors.accentGold
                                  : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 24),

                  // Generate Narrative Button
                  GestureDetector(
                    onTap: _isGeneratingNarrative ? null : _generateNarrative,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppColors.accentGold.withAlpha(77),
                        ),
                      ),
                      child: Center(
                        child: _isGeneratingNarrative
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: AppColors.accentGold,
                                ),
                              )
                            : Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(
                                    Icons.auto_awesome,
                                    color: AppColors.accentGold,
                                    size: 20,
                                  ),
                                  const SizedBox(width: 8),
                                  Text(
                                    '生成裂痕故事',
                                    style: AppTextStyles.labelLarge.copyWith(
                                      color: AppColors.accentGold,
                                    ),
                                  ),
                                ],
                              ),
                      ),
                    ),
                  ),

                  // Generated Narrative
                  if (_generatedNarrative != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppColors.accentGold.withAlpha(77),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '裂痕叙事',
                            style: AppTextStyles.labelMedium.copyWith(
                              color: AppColors.accentGold,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            _generatedNarrative!,
                            style: AppTextStyles.bodyMedium.copyWith(
                              fontStyle: FontStyle.italic,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  const SizedBox(height: 32),

                  // Save Button
                  GestureDetector(
                    onTap: _isLoading ? null : _saveProject,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: AppDecorations.primaryButton(
                        isDisabled: _isLoading,
                      ),
                      child: Center(
                        child: _isLoading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Text('保存项目', style: AppTextStyles.button),
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showImageSourceDialog() {
    _pickFromGallery();
  }
}
