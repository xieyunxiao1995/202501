import 'dart:io';
import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../theme/app_decorations.dart';
import '../../models/repair_project.dart';
import '../../services/storage_service.dart';
import '../../services/project_service.dart';
import '../../utils/constants.dart';
import '../../utils/formatters.dart';
import '../../config/routes.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// 画廊页面 - 深色霓虹风格
class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});

  @override
  GalleryScreenState createState() => GalleryScreenState();
}

class GalleryScreenState extends State<GalleryScreen>
    with WidgetsBindingObserver {
  late ProjectService _projectService;
  List<RepairProject> _projects = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initServices();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _loadProjects();
    }
  }

  Future<void> _initServices() async {
    final prefs = await SharedPreferences.getInstance();
    final storageService = StorageService(prefs);
    _projectService = ProjectService(storageService: storageService);
    await _loadProjects();
  }

  Future<void> refresh() async {
    await _loadProjects();
  }

  Future<void> _loadProjects() async {
    final projects = await _projectService.getActiveProjects();
    if (mounted) {
      setState(() {
        _projects = projects;
        _isLoading = false;
      });
    }
  }

  Future<void> _deleteProject(String projectId) async {
    await _projectService.deleteProject(projectId);
    await _loadProjects();
  }

  void _navigateToDetail(RepairProject project) {
    Navigator.of(context)
        .pushNamed(AppRoutes.repairDetail, arguments: project.id)
        .then((_) => _loadProjects());
  }

  /// 获取卡片渐变
  LinearGradient _getCardGradient(int index) {
    return AppColors.getGradientByIndex(index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _projects.isEmpty
            ? _buildEmptyState()
            : _buildProjectGrid(),
      ),
    );
  }

  /// 空状态 - 霓虹风格
  Widget _buildEmptyState() {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // 发光图标容器
            Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                gradient: AppColors.pinkGradient,
                borderRadius: BorderRadius.circular(70),
                boxShadow: [
                  // 发光效果
                  BoxShadow(
                    color: AppColors.pinkStart.withAlpha(128),
                    blurRadius: 30,
                    offset: const Offset(0, 8),
                    spreadRadius: -5,
                  ),
                  BoxShadow(
                    color: AppColors.pinkEnd.withAlpha(77),
                    blurRadius: 40,
                    offset: const Offset(0, 12),
                  ),
                ],
              ),
              child: const Icon(
                Icons.auto_fix_high,
                size: 60,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 32),
            Text(
              '暂无修复项目',
              style: AppTextStyles.headline2.copyWith(
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              '开始您的金缮之旅，创建第一个修复项目。',
              style: AppTextStyles.bodyMedium.copyWith(
                color: AppColors.textSecondary,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  /// 项目网格 - 深色卡片风格
  Widget _buildProjectGrid() {
    return RefreshIndicator(
      color: AppColors.primary,
      backgroundColor: AppColors.surface,
      onRefresh: _loadProjects,
      child: CustomScrollView(
        slivers: [
          // 头部
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('我的画廊', style: AppTextStyles.headline1),
                      const SizedBox(height: 6),
                      Text(
                        '${_projects.length} 个修复项目',
                        style: AppTextStyles.bodyMedium,
                      ),
                    ],
                  ),
                  // 统计按钮 - 霓虹风格
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed(AppRoutes.statistics);
                    },
                    child: Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        gradient: AppColors.purpleGradient,
                        borderRadius: BorderRadius.circular(18),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.purpleStart.withAlpha(128),
                            blurRadius: 16,
                            offset: const Offset(0, 6),
                            spreadRadius: -4,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.bar_chart_rounded,
                        color: Colors.white,
                        size: 26,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // 网格
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 0.68,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              delegate: SliverChildBuilderDelegate((context, index) {
                final project = _projects[index];
                return _buildProjectCard(project, index);
              }, childCount: _projects.length),
            ),
          ),
          // 底部间距
          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }

  /// 项目卡片 - 深色悬浮卡片
  Widget _buildProjectCard(RepairProject project, int index) {
    final gradient = _getCardGradient(index);
    return GestureDetector(
      onTap: () => _navigateToDetail(project),
      onLongPress: () => _showDeleteDialog(project),
      child: Container(
        decoration: AppDecorations.card(
          color: AppColors.surface,
          radius: 24,
          hasGlow: true,
          glowColor: gradient.colors.first,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // 图片区域 - 渐变叠加
            Expanded(
              flex: 3,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: gradient.colors.first.withAlpha(77),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: project.photoPaths.isNotEmpty
                    ? ClipRRect(
                        borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(24),
                          topRight: Radius.circular(24),
                        ),
                        child: Image.file(
                          File(project.photoPaths.first),
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(
                              Icons.image_not_supported_outlined,
                              color: Colors.white54,
                              size: 40,
                            );
                          },
                        ),
                      )
                    : const Center(
                        child: Icon(
                          Icons.image_outlined,
                          color: Colors.white54,
                          size: 40,
                        ),
                      ),
              ),
            ),
            // 内容区域
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      project.title,
                      style: AppTextStyles.labelLarge.copyWith(
                        color: AppColors.textPrimary,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    // 标签 - 渐变背景
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            gradient.colors.first.withAlpha(51),
                            gradient.colors.last.withAlpha(51),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        AppConstants.getDamageTypeLabel(project.damageType),
                        style: AppTextStyles.labelSmall.copyWith(
                          color: gradient.colors.first,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    // 进度条
                    Row(
                      children: [
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: LinearProgressIndicator(
                              value: project.techniqueProgress / 100,
                              backgroundColor: AppColors.surfaceLight,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                gradient.colors.first,
                              ),
                              minHeight: 6,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${project.techniqueProgress}%',
                          style: AppTextStyles.labelSmall.copyWith(
                            fontWeight: FontWeight.w600,
                            color: gradient.colors.first,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      AppFormatters.formatRelativeTime(project.updatedAt),
                      style: AppTextStyles.captionMuted,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 删除对话框 - 深色风格
  void _showDeleteDialog(RepairProject project) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text('删除项目？', style: AppTextStyles.headline3),
        content: Text(
          '确定要删除"${project.title}"吗？此操作无法撤销。',
          style: AppTextStyles.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              '取消',
              style: AppTextStyles.labelLarge.copyWith(
                color: AppColors.textSecondary,
              ),
            ),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteProject(project.id);
            },
            child: Text(
              '删除',
              style: AppTextStyles.labelLarge.copyWith(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
  }
}
