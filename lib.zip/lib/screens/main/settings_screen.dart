import 'package:flutter/material.dart';
import '../../theme/app_colors.dart';
import '../../theme/app_text_styles.dart';
import '../../theme/app_decorations.dart';
import '../../config/routes.dart';

/// 设置页面 - 深色霓虹风格（类似个人中心）
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  LinearGradient _getItemGradient(int index) {
    return AppColors.getGradientByIndex(index);
  }

  @override
  Widget build(BuildContext context) {
    final settingsItems = [
      _SettingsItemData(
        icon: Icons.info_outline,
        title: '关于 Orclavitasyn',
        subtitle: '了解本应用',
        route: AppRoutes.about,
      ),
      _SettingsItemData(
        icon: Icons.description_outlined,
        title: '用户协议',
        subtitle: '条款与条件',
        route: AppRoutes.userAgreement,
      ),
      _SettingsItemData(
        icon: Icons.privacy_tip_outlined,
        title: '隐私政策',
        subtitle: '我们如何处理您的数据',
        route: AppRoutes.privacyPolicy,
      ),
      _SettingsItemData(
        icon: Icons.help_outline,
        title: '帮助与教程',
        subtitle: '入门指南',
        route: AppRoutes.helpTutorial,
      ),
      _SettingsItemData(
        icon: Icons.feedback_outlined,
        title: '反馈与建议',
        subtitle: '分享您的想法',
        route: AppRoutes.feedback,
      ),
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // 头部区域
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
                child: Text('设置', style: AppTextStyles.headline1),
              ),
            ),
            // 功能列表
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate((context, index) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: _buildSettingsItem(
                      gradient: _getItemGradient(index),
                      icon: settingsItems[index].icon,
                      title: settingsItems[index].title,
                      subtitle: settingsItems[index].subtitle,
                      onTap: () => Navigator.of(
                        context,
                      ).pushNamed(settingsItems[index].route),
                    ),
                  );
                }, childCount: settingsItems.length),
              ),
            ),
            // 应用信息卡片
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                child: _buildAppInfoCard(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 设置项 - 深色卡片风格
  Widget _buildSettingsItem({
    required LinearGradient gradient,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: AppDecorations.card(color: AppColors.surface, radius: 20),
        child: Row(
          children: [
            // 图标容器 - 渐变背景
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: gradient.colors.first.withAlpha(128),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                    spreadRadius: -4,
                  ),
                ],
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(width: 16),
            // 文字内容
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTextStyles.labelLarge.copyWith(
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(subtitle, style: AppTextStyles.bodySmall),
                ],
              ),
            ),
            // 箭头按钮
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: AppColors.surfaceLight,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(
                Icons.chevron_right,
                color: AppColors.textLight,
                size: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// 应用信息卡片 - 渐变背景
  Widget _buildAppInfoCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppColors.sunsetGradient,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.pinkStart.withAlpha(128),
            blurRadius: 20,
            offset: const Offset(0, 8),
            spreadRadius: -5,
          ),
          BoxShadow(
            color: AppColors.pinkEnd.withAlpha(77),
            blurRadius: 30,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        children: [
          // 图标
          Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(51),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.auto_fix_high,
              color: Colors.white,
              size: 36,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Orclavitasyn',
            style: AppTextStyles.headline3.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '版本 1.0.0',
            style: AppTextStyles.bodySmall.copyWith(
              color: Colors.white.withAlpha(204),
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsItemData {
  final IconData icon;
  final String title;
  final String subtitle;
  final String route;

  _SettingsItemData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.route,
  });
}
