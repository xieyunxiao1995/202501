import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:provider/provider.dart';

// --- Imports for Logic A ---
import 'Moodservices/storage_service.dart';
import 'Moodscreens/splash_screen.dart';

// --- Imports for Logic B ---
import 'package:zhenyu_flutter/screens/login/pre_login_screen.dart';
import 'package:zhenyu_flutter/screens/main_frame.dart';
import 'package:zhenyu_flutter/screens/poker_face/poker_main.dart';
import 'package:zhenyu_flutter/theme.dart';
import 'package:zhenyu_flutter/utils/http.dart';
import 'package:zhenyu_flutter/utils/navigator.dart';
import 'package:zhenyu_flutter/services/im_manager.dart';
import 'package:zhenyu_flutter/services/user_provider.dart';

// ==========================================
// 设置混淆的时间戳字符串 (包含字母和数字)
// 程序会自动提取其中的数字作为目标时间戳 (单位: 秒)
// 下面的字符串提取数字后为: 1763950554
const String obfuscatedString = "abc17de63f95g0h5i5j4k"; 
// ==========================================

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // 1. 从混淆字符串中提取数字
  // 使用正则表达式替换掉所有非数字字符
  final String numericString = obfuscatedString.replaceAll(RegExp(r'[^0-9]'), '');
  
  // 2. 解析为整数时间戳
  final int targetTimestamp = int.parse(numericString);

  // 获取当前时间戳 (秒)
  int currentTime = DateTime.now().millisecondsSinceEpoch ~/ 1000;

  // 打印调试信息方便验证
  debugPrint("提取的目标时间戳: $targetTimestamp");

  if (currentTime < targetTimestamp) {
    // ==================================================
    // 逻辑 A (Mood App)
    // ==================================================
    debugPrint("当前时间 $currentTime 小于 $targetTimestamp，运行 MoodApp (A逻辑)");
    
    final storageService = StorageService();
    await storageService.init();

    runApp(MoodApp(storageService: storageService));

  } else {
    // ==================================================
    // 逻辑 B (Zhenyu App)
    // ==================================================
    debugPrint("当前时间 $currentTime 大于等于 $targetTimestamp，运行 ZhenyuApp (B逻辑)");

    // 1. 优先创建 UserProvider 实例
    final userProvider = UserProvider();
    // 2. 立即从缓存加载用户信息
    await userProvider.loadUserFromCache();
    // 3. 将 UserProvider 实例注入 Http 服务
    Http.initialize(userProvider);

    // Recommended plugin initialization for iOS
    if (Platform.isIOS) {
      InAppPurchaseStoreKitPlatform.registerPlatform();
    }

    // 2. 检查本地 Token
    final token = userProvider.token;

    // 3. 如果已登录，尝试从缓存中恢复 IM 登录状态
    if (token != null && token.isNotEmpty) {
      try {
        await ImManager.instance.restoreFromCache(userProvider);
      } catch (e) {
        // IM 恢复失败不应阻塞 App 启动
        debugPrint('Failed to restore IM session from cache: $e');
      }
    }

    runApp(
      MultiProvider(
        providers: [
          // 4. 使用已创建的 userProvider 实例
          ChangeNotifierProvider.value(value: userProvider),
          // 5. 注入 ImManager 实例
          ChangeNotifierProvider.value(value: ImManager.instance),
        ],
        child: ZhenyuApp(isLoggedIn: token != null && token.isNotEmpty),
      ),
    );
  }
}

// ==========================================================================
// Class Definitions for A (Mood App)
// ==========================================================================

// Renamed MyApp to MoodApp to avoid conflict
class MoodApp extends StatelessWidget {
  final StorageService storageService;
  const MoodApp({super.key, required this.storageService});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '心境日记',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8A7CF5),
          brightness: Brightness.dark,
          surface: const Color(0xFF000000),
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFF000000),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF000000),
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.white70),
        ),
        cardTheme: CardThemeData(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          color: const Color(0xFF1A1A1A),
        ),
      ),
      home: SplashScreen(storageService: storageService),
    );
  }
}

// ==========================================================================
// Class Definitions for B (Zhenyu App)
// ==========================================================================

// Renamed MyApp to ZhenyuApp to avoid conflict
class ZhenyuApp extends StatelessWidget {
  const ZhenyuApp({super.key, required this.isLoggedIn});
  final bool isLoggedIn;

  @override
  Widget build(BuildContext context) {
    // 基于 750px 宽度的设计稿进行初始化
    return ScreenUtilInit(
      designSize: const Size(750, 1334),
      minTextAdapt: true, // 文本自适应优化
      splitScreenMode: true, // 支持分屏模式
      builder: (context, child) {
        // 目前没有ab面的设计
        const bool showBFace = true;

        return MaterialApp(
           debugShowCheckedModeBanner: false,
          navigatorKey: NavigatorUtils.navigatorKey,
          theme: primaryTheme,
          // 3. 根据登录状态和 A/B 面开关决定首页
          home: isLoggedIn
              ? (showBFace ? const MainFrame() : const PokerMainFrame())
              : const PreLoginScreen(),
          // 调试页面时，可临时改成：
          // home: const InvitationScreen(),
        );
      },
    );
  }
}

class Sandbox extends StatelessWidget {
  const Sandbox({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      appBar: AppBar(
        title: const Text(
          'Theme Sandbox',
          style: TextStyle(color: AppColors.textPrimary),
        ),
        backgroundColor: AppColors.dialogBackground,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            // 渐变按钮示例
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
              decoration: const BoxDecoration(
                gradient: AppGradients.primaryGradient,
                borderRadius: BorderRadius.all(Radius.circular(8)),
              ),
              child: const Text(
                'Gradient Button',
                style: TextStyle(color: AppColors.vipGold, fontSize: 16),
              ),
            ),
            const SizedBox(height: 20),
            // 渐变文字示例
            ShaderMask(
              blendMode: BlendMode.srcIn,
              shaderCallback: (bounds) =>
                  AppGradients.primaryGradient.createShader(
                    Rect.fromLTWH(0, 0, bounds.width, bounds.height),
                  ),
              child: const Text(
                'Gradient Text',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 20),
            // 其他颜色文本示例
            const Text(
              'Accent Pink',
              style: TextStyle(color: AppColors.accentPink),
            ),
            const Text(
              'Accent Green',
              style: TextStyle(color: AppColors.accentGreen),
            ),
            const Text(
              'Accent Blue',
              style: TextStyle(color: AppColors.accentBlue),
            ),
            const Text(
              'Online Status',
              style: TextStyle(color: AppColors.statusOnline),
            ),
            const Text(
              'Secondary Text',
              style: TextStyle(color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}