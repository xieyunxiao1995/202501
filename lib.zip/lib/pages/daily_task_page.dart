import 'dart:async';
import 'package:flutter/material.dart';
import '../models/daily_task_model.dart';
import '../core/app_colors.dart';

class DailyTaskPage extends StatefulWidget {
  final DailyTaskManager taskManager;
  final Function(int) onClaimReward;

  const DailyTaskPage({
    super.key,
    required this.taskManager,
    required this.onClaimReward,
  });

  @override
  State<DailyTaskPage> createState() => _DailyTaskPageState();
}

class _DailyTaskPageState extends State<DailyTaskPage> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    // 每分钟刷新一次倒计时
    _timer = Timer.periodic(const Duration(minutes: 1), (timer) {
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isSmallScreen = MediaQuery.of(context).size.height < 600;
    final allTasks = widget.taskManager.getDailyTasks();

    // 排序逻辑：
    // 1. 已完成但未领取 (Priority 1)
    // 2. 进行中 (Priority 2)
    // 3. 已领取 (Priority 3)
    final tasks = List<DailyTask>.from(allTasks)
      ..sort((a, b) {
        final progA = widget.taskManager.getProgress(a.id);
        final progB = widget.taskManager.getProgress(b.id);

        int getPriority(TaskProgress p) {
          if (p.isCompleted && !p.isClaimed) return 0;
          if (!p.isCompleted) return 1;
          return 2;
        }

        return getPriority(progA).compareTo(getPriority(progB));
      });

    final completedTasks = tasks
        .where((task) => widget.taskManager.getProgress(task.id).isCompleted)
        .length;
    final claimedTasks = tasks
        .where((task) => widget.taskManager.getProgress(task.id).isClaimed)
        .length;
    final totalRewards = tasks.fold<int>(0, (sum, task) => sum + task.reward);

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: CustomScrollView(
        slivers: [
          _buildSliverAppBar(isSmallScreen),
          SliverToBoxAdapter(
            child: _buildStatsHeader(
              completedTasks,
              tasks.length,
              claimedTasks,
              totalRewards,
              isSmallScreen,
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.all(isSmallScreen ? 12 : 16),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate((context, index) {
                final task = tasks[index];
                final progress = widget.taskManager.getProgress(task.id);
                return _buildTaskCard(task, progress, isSmallScreen);
              }, childCount: tasks.length),
            ),
          ),
          SliverToBoxAdapter(child: SizedBox(height: isSmallScreen ? 16 : 32)),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar(bool isSmallScreen) {
    return SliverAppBar(
      expandedHeight: isSmallScreen ? 100 : 120,
      pinned: true,
      backgroundColor: AppColors.bg,
      elevation: 0,
      centerTitle: true,
      title: Text(
        '每日任务',
        style: TextStyle(
          color: Colors.white,
          fontSize: isSmallScreen ? 16 : 18,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.2,
        ),
      ),
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF1A1A1A), Color(0xFF0D0D0D)],
            ),
          ),
          child: Stack(
            children: [
              Positioned(
                right: -20,
                top: -20,
                child: Icon(
                  Icons.task_alt,
                  size: isSmallScreen ? 100 : 120,
                  color: Colors.white.withValues(alpha: 0.05),
                ),
              ),
              Positioned(
                left: 20,
                bottom: isSmallScreen ? 12 : 20,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '刷新倒计时',
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: 0.5),
                        fontSize: isSmallScreen ? 10 : 12,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getNextResetTime(),
                      style: TextStyle(
                        color: Colors.amber,
                        fontSize: isSmallScreen ? 16 : 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'monospace',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatsHeader(
    int completed,
    int total,
    int claimed,
    int totalRewards,
    bool isSmallScreen,
  ) {
    final allClaimed = claimed == total;

    return Container(
      margin: EdgeInsets.fromLTRB(16, isSmallScreen ? 8 : 16, 16, 0),
      padding: EdgeInsets.all(isSmallScreen ? 12 : 20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          if (allClaimed && total > 0)
            Container(
              margin: EdgeInsets.only(bottom: isSmallScreen ? 12 : 16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Colors.green, Color(0xFF2E7D32)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.green.withValues(alpha: 0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.check_circle,
                    color: Colors.white,
                    size: isSmallScreen ? 16 : 18,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '今日任务全部完成！',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: isSmallScreen ? 12 : 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  '完成进度',
                  '$claimed/$total',
                  Icons.assignment_turned_in,
                  AppColors.primary,
                  isSmallScreen,
                ),
              ),
              Container(
                width: 1,
                height: isSmallScreen ? 30 : 40,
                color: Colors.white.withValues(alpha: 0.1),
              ),
              Expanded(
                child: _buildStatItem(
                  '总奖励',
                  '$totalRewards',
                  Icons.stars,
                  Colors.amber,
                  isSmallScreen,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(
    String label,
    String value,
    IconData icon,
    Color color,
    bool isSmallScreen,
  ) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: isSmallScreen ? 14 : 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withValues(alpha: 0.5),
                fontSize: isSmallScreen ? 11 : 12,
              ),
            ),
          ],
        ),
        SizedBox(height: isSmallScreen ? 4 : 8),
        Text(
          value,
          style: TextStyle(
            color: Colors.white,
            fontSize: isSmallScreen ? 18 : 24,
            fontWeight: FontWeight.bold,
            fontFamily: 'monospace',
          ),
        ),
      ],
    );
  }

  Widget _buildTaskCard(
    DailyTask task,
    TaskProgress progress,
    bool isSmallScreen,
  ) {
    final isCompleted = progress.isCompleted;
    final isClaimed = progress.isClaimed;
    final progressPercent = (progress.current / task.target).clamp(0.0, 1.0);

    return Container(
      margin: EdgeInsets.only(bottom: isSmallScreen ? 12 : 16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isCompleted && !isClaimed
              ? Colors.green.withValues(alpha: 0.5)
              : Colors.white.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            // 状态指示条 - 使用 Positioned.fill 配合 right: null 来撑满高度
            Positioned.fill(
              right: null,
              child: Container(
                width: 6,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: isClaimed
                        ? [Colors.grey, Colors.grey.shade700]
                        : isCompleted
                        ? [Colors.green, Colors.lightGreen]
                        : [AppColors.primary, AppColors.secondary],
                  ),
                ),
              ),
            ),
            // 内容区
            Padding(
              padding: EdgeInsets.fromLTRB(
                22,
                isSmallScreen ? 12 : 16,
                16,
                isSmallScreen ? 12 : 16,
              ), // 左侧增加 padding 避开指示条
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: isSmallScreen ? 36 : 40,
                        height: isSmallScreen ? 36 : 40,
                        decoration: BoxDecoration(
                          color: isCompleted
                              ? Colors.green.withValues(alpha: 0.1)
                              : AppColors.bg,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          _getTaskIcon(task.type),
                          color: isCompleted ? Colors.green : AppColors.textSub,
                          size: isSmallScreen ? 18 : 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              task.name,
                              style: TextStyle(
                                color: isCompleted && !isClaimed
                                    ? Colors.green
                                    : AppColors.textMain,
                                fontSize: isSmallScreen ? 14 : 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              task.description,
                              style: TextStyle(
                                color: AppColors.textSub,
                                fontSize: isSmallScreen ? 11 : 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (isClaimed)
                        Icon(
                          Icons.check_circle,
                          color: Colors.grey,
                          size: isSmallScreen ? 18 : 20,
                        )
                      else if (isCompleted)
                        _buildPulseButton(task, isSmallScreen),
                    ],
                  ),
                  SizedBox(height: isSmallScreen ? 12 : 16),
                  // 进度条
                  LayoutBuilder(
                    builder: (context, constraints) {
                      return Stack(
                        children: [
                          Container(
                            height: isSmallScreen ? 4 : 6,
                            decoration: BoxDecoration(
                              color: AppColors.bg,
                              borderRadius: BorderRadius.circular(3),
                            ),
                          ),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 500),
                            height: isSmallScreen ? 4 : 6,
                            width: constraints.maxWidth * progressPercent,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: isCompleted
                                    ? [Colors.green, Colors.lightGreen]
                                    : [AppColors.primary, Colors.amber],
                              ),
                              borderRadius: BorderRadius.circular(3),
                              boxShadow: isCompleted
                                  ? [
                                      BoxShadow(
                                        color: Colors.green.withValues(
                                          alpha: 0.3,
                                        ),
                                        blurRadius: 4,
                                        offset: const Offset(0, 2),
                                      ),
                                    ]
                                  : null,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.stars,
                            color: Colors.amber,
                            size: isSmallScreen ? 12 : 14,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '${task.reward} 灵气',
                            style: TextStyle(
                              color: Colors.amber,
                              fontSize: isSmallScreen ? 11 : 12,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      Text(
                        '${progress.current} / ${task.target}',
                        style: TextStyle(
                          color: isCompleted ? Colors.green : AppColors.textSub,
                          fontSize: isSmallScreen ? 11 : 12,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPulseButton(DailyTask task, bool isSmallScreen) {
    return ElevatedButton(
      onPressed: () => _claimReward(task),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        elevation: 0,
        padding: EdgeInsets.symmetric(
          horizontal: isSmallScreen ? 12 : 16,
          vertical: isSmallScreen ? 6 : 8,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      child: Text(
        '领取',
        style: TextStyle(
          fontSize: isSmallScreen ? 11 : 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  IconData _getTaskIcon(TaskType type) {
    switch (type) {
      case TaskType.explore:
        return Icons.explore;
      case TaskType.collectBeast:
        return Icons.pets;
      case TaskType.evolveBeast:
        return Icons.trending_up;
      case TaskType.battleWin:
        return Icons.emoji_events;
      case TaskType.forgeBeast:
        return Icons.local_fire_department;
      case TaskType.gatherSpirit:
        return Icons.blur_circular;
    }
  }

  void _claimReward(DailyTask task) {
    if (widget.taskManager.claimTask(task.id)) {
      widget.onClaimReward(task.reward);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('获得 ${task.reward} 灵气！'),
            backgroundColor: Colors.green,
            duration: const Duration(seconds: 2),
          ),
        );
        setState(() {});
      }
    }
  }

  String _getNextResetTime() {
    final now = DateTime.now();
    final tomorrow = DateTime(now.year, now.month, now.day + 1);
    final difference = tomorrow.difference(now);

    final hours = difference.inHours;
    final minutes = difference.inMinutes % 60;

    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}';
  }
}
