import 'package:flutter/material.dart';
import '../../utils/constants.dart';

class BodySchemaPainter extends CustomPainter {
  final double scale;

  BodySchemaPainter({this.scale = 1.0});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.inkBlack.withOpacity(0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2 * scale
      ..strokeCap = StrokeCap.round;

    final cx = size.width / 2;
    // final cy = size.height / 2;
    
    // Using relative coordinates
    final headY = size.height * 0.1;
    final bodyY = size.height * 0.35;
    final legY = size.height * 0.85; // Adjusted
    
    final radius = 28.0 * scale;
    final offset20 = 20.0 * scale;
    final offset30 = 30.0 * scale;

    // Head to Body
    canvas.drawLine(Offset(cx, headY + radius), Offset(cx, bodyY - radius), paint);
    
    // Body to Legs
    canvas.drawLine(Offset(cx, bodyY + radius), Offset(cx, legY - radius), paint);
    
    // Body to Tail (Curve)
    final path = Path();
    path.moveTo(cx + offset20, bodyY);
    path.quadraticBezierTo(size.width * 0.8, bodyY + offset20, size.width * 0.9, size.height * 0.7);
    canvas.drawPath(path, paint);
    
    // Body to Soul (Dashed/Spiritual)
    final soulPaint = Paint()
      ..color = Colors.purple.withOpacity(0.1)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1 * scale
      ..strokeCap = StrokeCap.round;
      
    final soulX = size.width * 0.1;
    final soulY = size.height * 0.7;
    
    canvas.drawCircle(Offset(soulX + radius, soulY), offset30, soulPaint..style = PaintingStyle.stroke);
    canvas.drawLine(Offset(cx - offset20, bodyY), Offset(soulX + radius + offset20, soulY - offset20), soulPaint);
  }

  @override
  bool shouldRepaint(covariant BodySchemaPainter oldDelegate) => oldDelegate.scale != scale;
}
