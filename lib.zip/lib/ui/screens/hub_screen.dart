import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../services/game_service.dart';
import '../../utils/constants.dart';
import '../../models/player.dart'; // Import Player
import 'map_screen.dart';
import 'map_selection_screen.dart';
import 'compendium_screen.dart';
import 'shop_screen.dart';
import 'task_screen.dart';
import 'inventory_screen.dart';
import 'settings_screen.dart';
import 'skill_screen.dart';

class HubScreen extends StatelessWidget {
  final GameService gameService;

  const HubScreen({super.key, required this.gameService});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: gameService,
      builder: (context, child) {
        final player = gameService.player;
        if (player == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));

        final screenWidth = MediaQuery.of(context).size.width;
        final isSmallScreen = screenWidth < 380;

        return Scaffold(
          backgroundColor: AppColors.bgPaper,
          body: Stack(
            children: [
              // Background Pattern
              Positioned.fill(
                child: Opacity(
                  opacity: 0.1,
                  child: Image.network(
                    'https://www.transparenttextures.com/patterns/wood-pattern.png',
                    repeat: ImageRepeat.repeat,
                    errorBuilder: (c, e, s) => Container(color: AppColors.woodLight),
                  ),
                ),
              ),

              // Top Bar
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: SafeArea(
                  child: Padding(
                    padding: EdgeInsets.all(isSmallScreen ? 16.0 : 24.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('墨室', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontSize: isSmallScreen ? 32 : null)),
                            const SizedBox(height: 8),
                            // Level Display
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text('Lv.${player.level}', style: GoogleFonts.maShanZheng(fontSize: isSmallScreen ? 18 : 20, color: AppColors.inkBlack)),
                                const SizedBox(width: 8),
                                SizedBox(
                                  width: isSmallScreen ? 60 : 80,
                                  height: 4,
                                  child: LinearProgressIndicator(
                                    value: player.currentExp / player.maxExp,
                                    backgroundColor: Colors.grey[300],
                                    valueColor: const AlwaysStoppedAnimation(AppColors.inkRed),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                _StatBadge(label: '理智', value: '${player.sanity}/${player.maxSanity}', isSmallScreen: isSmallScreen),
                                const SizedBox(width: 16),
                                _StatBadge(label: '墨韵', value: '${player.ink}/${player.maxInk}', isSmallScreen: isSmallScreen),
                              ],
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                border: Border.all(color: AppColors.inkBlack),
                                color: Colors.white.withOpacity(0.5),
                              ),
                              child: const Text('庚午'),
                            ),
                            const SizedBox(width: 12),
                            Container(
                              decoration: BoxDecoration(
                                border: Border.all(color: AppColors.inkBlack),
                                color: Colors.white.withOpacity(0.5),
                              ),
                              child: IconButton(
                                icon: const Icon(Icons.settings_outlined, color: AppColors.inkBlack),
                                onPressed: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (_) => const SettingsScreen()),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Central Menu Area
              Positioned.fill(
                top: isSmallScreen ? 80 : 100,
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Expedition (Main)
                        GestureDetector(
                          onTap: () {
                            Navigator.of(context).push(
                              MaterialPageRoute(builder: (_) => MapSelectionScreen(gameService: gameService)),
                            );
                          },
                          child: Container(
                            width: isSmallScreen ? 240 : 280,
                            height: isSmallScreen ? 140 : 160,
                            decoration: BoxDecoration(
                              color: const Color(0xFFF3EFE6),
                              border: const Border.symmetric(
                                horizontal: BorderSide(color: AppColors.woodDark, width: 6),
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.2),
                                  blurRadius: 10,
                                  offset: const Offset(0, 5),
                                )
                              ],
                            ),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Text(
                                  '山海',
                                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                                    fontSize: isSmallScreen ? 60 : 80,
                                    color: Colors.black.withOpacity(0.05),
                                  ),
                                ),
                                Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      '出征',
                                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                                        color: AppColors.inkBlack,
                                        fontWeight: FontWeight.bold,
                                        fontSize: isSmallScreen ? 36 : null,
                                      ),
                                    ),
                                    Container(height: 2, width: 40, color: AppColors.inkRed, margin: const EdgeInsets.symmetric(vertical: 8)),
                                    const Text('踏破虚空', style: TextStyle(letterSpacing: 4, color: AppColors.woodLight)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        
                        const SizedBox(height: 30),

                        // Secondary Menu Grid
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final cardSize = isSmallScreen ? 100.0 : 130.0;
                            final spacing = isSmallScreen ? 12.0 : 20.0;
                            
                            return Wrap(
                              spacing: spacing,
                              runSpacing: spacing,
                              alignment: WrapAlignment.center,
                              children: [
                                _buildHubCard(
                                  context, 
                                  '行囊', 
                                  '万象', 
                                  Icons.backpack_outlined,
                                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => InventoryScreen(gameService: gameService))),
                                  size: cardSize,
                                ),
                                _buildHubCard(
                                  context, 
                                  '商店', 
                                  '奇珍', 
                                  Icons.storefront_outlined,
                                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopScreen(gameService: gameService))),
                                  size: cardSize,
                                ),
                                _buildHubCard(
                                  context, 
                                  '图鉴', 
                                  '博古', 
                                  Icons.menu_book_outlined,
                                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CompendiumScreen())),
                                  size: cardSize,
                                ),
                                _buildHubCard(
                                  context, 
                                  '任务', 
                                  '天道', 
                                  Icons.assignment_outlined,
                                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskScreen(gameService: gameService))),
                                  size: cardSize,
                                ),
                                _buildHubCard(
                                  context, 
                                  '功法', 
                                  '神通', 
                                  Icons.auto_fix_high_outlined,
                                  () => Navigator.push(context, MaterialPageRoute(builder: (_) => SkillScreen(gameService: gameService))),
                                  size: cardSize,
                                ),
                              ],
                            );
                          }
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildHubCard(BuildContext context, String title, String bgText, IconData icon, VoidCallback onTap, {double size = 130.0}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: const Color(0xFFF3EFE6),
          border: Border.all(color: AppColors.woodDark, width: 2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 5,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              right: -10,
              bottom: -10,
              child: Text(
                bgText,
                style: GoogleFonts.maShanZheng(
                  fontSize: size * 0.46, // Dynamic font size
                  color: Colors.black.withOpacity(0.03),
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: AppColors.inkBlack, size: size * 0.25),
                SizedBox(height: size * 0.06),
                Text(
                  title,
                  style: GoogleFonts.maShanZheng(
                    fontSize: size * 0.17,
                    color: AppColors.inkBlack,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatBadge extends StatelessWidget {
  final String label;
  final String value;
  final bool isSmallScreen;

  const _StatBadge({required this.label, required this.value, this.isSmallScreen = false});

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        children: [
          TextSpan(text: '$label ', style: TextStyle(fontSize: isSmallScreen ? 10 : 12, color: Colors.grey)),
          TextSpan(text: value, style: TextStyle(fontSize: isSmallScreen ? 16 : 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
