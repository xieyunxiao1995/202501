import 'package:flutter/material.dart';

class AppColors {
  static const Color bgPaper = Color(0xFFEADDCF);
  static const Color inkBlack = Color(0xFF0A0A0A);
  static const Color inkRed = Color(0xFF8A1C1C);
  static const Color woodDark = Color(0xFF3E2723);
  static const Color woodLight = Color(0xFF5D4037);
  static const Color stoneDark = Color(0xFF1A1A1A);
  static const Color stoneLight = Color(0xFFCCCCCC);
  static const Color gold = Color(0xFFD4AF37);

  static const Color elementMetal = Color(0xFFE0E0E0); // Gold/White
  static const Color elementWood = Color(0xFF4CAF50); // Green
  static const Color elementWater = Color(0xFF2980B9); // Blue
  static const Color elementFire = Color(0xFFC0392B); // Red
  static const Color elementEarth = Color(0xFF795548); // Brown

  static Color getPowerColor(int power) {
    if (power < 20) return Colors.grey;
    if (power < 50) return Colors.green;
    if (power < 100) return Colors.blue;
    if (power < 200) return Colors.purple;
    return inkRed; // Orange/Red for legendary
  }
}

class AppTextStyles {
  // We will use GoogleFonts in the theme, here we define keys or helpers if needed
}
