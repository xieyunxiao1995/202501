import 'models/faction.dart';
import 'models/rarity.dart';
import 'models/hero.dart';
import 'models/stage.dart';

const Map<FactionType, Faction> FACTIONS = {
  FactionType.fire: Faction.FIRE,
  FactionType.water: Faction.WATER,
  FactionType.wind: Faction.WIND,
  FactionType.light: Faction.LIGHT,
  FactionType.dark: Faction.DARK,
};

const Map<RarityType, Rarity> RARITIES = {
  RarityType.UR: Rarity.UR,
  RarityType.SSR: Rarity.SSR,
  RarityType.SR: Rarity.SR,
  RarityType.R: Rarity.R,
};

const List<HeroTemplate> HERO_TEMPLATES = [
  HeroTemplate(
    id: 'h1',
    name: '芙蕾雅',
    title: '绯红伞盖',
    rarity: RarityType.UR,
    faction: FactionType.fire,
    heroClass: HeroClass.guardian,
    baseHp: 15000,
    baseAtk: 1200,
    baseDef: 800,
    baseSpd: 100,
    skills: ['阳炎斩击', '赤狐庇护伞'],
  ),
  HeroTemplate(
    id: 'h2',
    name: '洛缇娅',
    title: '绘梦游星',
    rarity: RarityType.UR,
    faction: FactionType.water,
    heroClass: HeroClass.mage,
    baseHp: 8000,
    baseAtk: 2500,
    baseDef: 400,
    baseSpd: 120,
    skills: ['墨水飞溅', '神笔巨鲸'],
  ),
  HeroTemplate(
    id: 'h3',
    name: '苍刃',
    title: '疾风剑影',
    rarity: RarityType.SSR,
    faction: FactionType.wind,
    heroClass: HeroClass.assassin,
    baseHp: 9000,
    baseAtk: 1800,
    baseDef: 300,
    baseSpd: 150,
    skills: ['风刃', '绝影瞬狱杀'],
  ),
];

const List<Stage> STAGES = [
  Stage(
    id: 1,
    name: '1-1 史莱姆之森',
    recLevel: 1,
    bg: 'forest',
    drops: ['EXP', 'Gold'],
    story: [
      {"speaker": "旁白", "content": "欢迎来到一界，这里是你旅程的起点。"},
      {"speaker": "史莱姆", "content": "咕噜咕噜！"},
    ],
  ),
  Stage(
    id: 2,
    name: '1-2 哥布林营地',
    recLevel: 15,
    bg: 'camp',
    drops: ['Gold'],
    story: [
      {"speaker": "苍刃", "content": "小心，前方有哥布林的斥候。"},
    ],
  ),
  Stage(
    id: 3,
    name: '1-3 遗落圣殿',
    recLevel: 40,
    bg: 'temple',
    drops: ['Gems'],
    story: [
      {"speaker": "米迦勒", "content": "圣殿不容侵犯，净化这里的黑暗！"},
    ],
  ),
  Stage(
    id: 4,
    name: '1-4 诸神黄昏',
    recLevel: 80,
    bg: 'altar',
    drops: ['UR Shards'],
    story: [
      {"speaker": "深渊统领", "content": "凡人，感受来自虚空的恐惧吧！"},
    ],
  ),
  // 新增 10 个关卡
  Stage(
    id: 5,
    name: '2-1 霜雪冻土',
    recLevel: 120,
    bg: 'snow',
    drops: ['Blue Ore'],
    story: [
      {"speaker": "洛缇娅", "content": "这里的画纸都被冻住了，我们要点把火。"},
    ],
  ),
  Stage(
    id: 6,
    name: '2-2 熔岩之心',
    recLevel: 180,
    bg: 'lava',
    drops: ['Fire Core'],
    story: [
      {"speaker": "芙蕾雅", "content": "这温度...正是红伞起舞的好地方。"},
    ],
  ),
  Stage(
    id: 7,
    name: '2-3 迷幻之森',
    recLevel: 250,
    bg: 'mist',
    drops: ['Herb'],
    story: [
      {"speaker": "旁白", "content": "大雾弥漫，你的感官开始出现幻觉。"},
    ],
  ),
  Stage(
    id: 8,
    name: '2-4 机械废都',
    recLevel: 350,
    bg: 'city',
    drops: ['Parts'],
    story: [
      {"speaker": "苍刃", "content": "金属的气味，这些守卫没有灵魂。"},
    ],
  ),
  Stage(
    id: 9,
    name: '2-5 远古遗迹',
    recLevel: 500,
    bg: 'ruins',
    drops: ['Relic'],
    story: [
      {"speaker": "米迦勒", "content": "这是诸神留下的最后警告。"},
    ],
  ),
  Stage(
    id: 10,
    name: '3-1 极光之巅',
    recLevel: 700,
    bg: 'sky',
    drops: ['Feather'],
    story: [
      {"speaker": "旁白", "content": "站在世界之巅，风暴正在酝酿。"},
    ],
  ),
  Stage(
    id: 11,
    name: '3-2 虚空缝隙',
    recLevel: 1000,
    bg: 'void',
    drops: ['Void Soul'],
    story: [
      {"speaker": "莉莉丝", "content": "欢迎来到我的领地，小虫子们。"},
    ],
  ),
  Stage(
    id: 12,
    name: '3-3 星辰大海',
    recLevel: 1500,
    bg: 'space',
    drops: ['Stardust'],
    story: [
      {"speaker": "旁白", "content": "这一战，跨越了星系的距离。"},
    ],
  ),
  Stage(
    id: 13,
    name: '3-4 混沌之源',
    recLevel: 2200,
    bg: 'chaos',
    drops: ['Core'],
    story: [
      {"speaker": "苍刃", "content": "因果律已经崩坏，只能杀出一条血路。"},
    ],
  ),
  Stage(
    id: 14,
    name: '终章：一界之门',
    recLevel: 3500,
    bg: 'gate',
    drops: ['Everything'],
    story: [
      {"speaker": "神秘人", "content": "旅途的终点，亦是起点。"},
    ],
  ),
];
