import 'package:flutter/material.dart';
import '../widgets/game_background.dart';

class PreviewView extends StatelessWidget {
  const PreviewView({super.key});

  @override
  Widget build(BuildContext context) {
    return GameBackground(
      backgroundImage: BackgroundUtil.getBgByScene('preview'),
      overlayOpacity: BackgroundUtil.getOverlayOpacityForScene('preview'),
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('未来视界'),
          backgroundColor: Colors.transparent,
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildPreviewCard(
              '全新 UR 英雄：莉莉丝',
              '深渊魔女即将降临一界，掌控虚空之力的最强辅助。',
              '2026-03-15',
              Colors.purpleAccent,
            ),
            const SizedBox(height: 16),
            _buildPreviewCard(
              '新地图：浮空之岛',
              '跨越云端的挑战，掉落全新的传说级装备碎片。',
              '2026-04-01',
              Colors.blueAccent,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPreviewCard(
    String title,
    String desc,
    String date,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [color.withOpacity(0.4), Colors.black12],
        ),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              Icon(Icons.new_releases, color: color),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            desc,
            style: const TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const Divider(height: 30, color: Colors.white10),
          Text(
            '预计开启: $date',
            style: TextStyle(
              color: color,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
