import 'package:flutter/material.dart';
import 'dart:async';
import '../state/game_state.dart';
import 'main_game_screen.dart';

/// 多页游戏介绍闪屏
class StorySplashScreen extends StatefulWidget {
  const StorySplashScreen({super.key});

  @override
  State<StorySplashScreen> createState() => _StorySplashScreenState();
}

class _StorySplashScreenState extends State<StorySplashScreen>
    with SingleTickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  bool _isLoading = false;

  // 故事页面数据
  final List<StoryPageData> _storyPages = [
    StoryPageData(
      icon: Icons.auto_awesome,
      title: '一界旅',
      subtitle: 'JOURNEY OF ONE REALM',
      description: '在遥远的异世界，存在着一个神秘的旅馆\n这里是旅者们的归宿，也是冒险的起点',
      storyText: '当你睁开双眼，发现自己身处一座古老的旅馆之中\n窗外是陌生的星空，耳边传来奇异生物的鸣叫\n一个温柔的声音在耳边轻语：\n"欢迎来到，一界旅"',
      color: const Color(0xff8c6751),
    ),
    StoryPageData(
      icon: Icons.groups,
      title: '邂逅英雄',
      subtitle: 'HEROES GATHERING',
      description: '数十位来自不同阵营的英雄等待与你缔结契约\n火、水、风、光、暗，五大阵营相互克制',
      storyText: '红发的狐耳少女撑着油纸伞，对你露出温暖的微笑\n"我是芙蕾雅，将成为你最坚实的后盾"\n绘制巨鲸的魔法少女洛缇娅\n以及风系刺客苍刃...\n他们都在等待你的召唤',
      color: const Color(0xffd49d6a),
    ),
    StoryPageData(
      icon: Icons.local_fire_department,
      title: '策略战斗',
      subtitle: 'STRATEGIC COMBAT',
      description: '5v5 回合制自动战斗，技能组合千变万化\n天赋、符文、装备，打造最强阵容',
      storyText: '战斗的号角已经吹响\n阳炎斩击划破长空，神笔巨鲸掀起狂澜\n疾风剑影穿梭敌阵\n运用你的智慧，制定战术\n成为真正的异界领主',
      color: const Color(0xffc75c5c),
    ),
    StoryPageData(
      icon: Icons.castle,
      title: '旅馆经营',
      subtitle: 'INN MANAGEMENT',
      description: '温泉、壁炉、商柜...打造属于你的异界旅馆\n与女仆互动，招待各方旅者',
      storyText: '这座古老的旅馆有着悠久的历史\n议事壁炉见证着公会的荣耀\n温泉中恢复着冒险的疲惫\n商柜里陈列着珍贵的宝物\n这里，就是你的家',
      color: const Color(0xff5c8cc7),
    ),
    StoryPageData(
      icon: Icons.trending_up,
      title: '深度养成',
      subtitle: 'DEEP PROGRESSION',
      description: '升级、升星、天赋、符文...多维度的成长体系\n遣返系统，无损重置，自由尝试阵容',
      storyText: '从一名普通的旅者，成长为战力百万的强者\n每一次进阶都是质的飞跃\n每一颗红星都代表着荣耀\n即使选错也无妨，遣返系统会返还所有资源\n你的成长之路，没有弯路',
      color: const Color(0xff9d67c7),
    ),
  ];

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _fadeController.forward();

    // 预加载游戏数据
    _preloadGameData();
  }

  Future<void> _preloadGameData() async {
    // 提前加载数据，但不跳转，等用户操作或最后一页自动跳转
    await GameState.load();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  void _onPageChanged(int page) {
    setState(() {
      _currentPage = page;
    });
  }

  void _nextPage() {
    if (_currentPage < _storyPages.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 400),
        curve: Curves.easeInOut,
      );
    } else {
      _startGame();
    }
  }

  void _startGame() async {
    if (_isLoading) return;
    setState(() => _isLoading = true);

    final loadedState = await GameState.load();

    if (!mounted) return;

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) =>
            MainGameScreen(initialState: loadedState),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: const Duration(milliseconds: 800),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xff1a1a2e),
              Color(0xff16213e),
              Color(0xff0f0f23),
            ],
          ),
        ),
        child: Stack(
          children: [
            // 背景装饰星星
            ..._buildBackgroundStars(),

            // 主内容区域
            SafeArea(
              child: Column(
                children: [
                  // 顶部跳过按钮
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        TextButton(
                          onPressed: _isLoading ? null : _startGame,
                          child: Text(
                            '跳过',
                            style: TextStyle(
                              color: Colors.white.withValues(alpha: 0.7),
                              fontSize: 14,
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // 故事页面视图
                  Expanded(
                    child: FadeTransition(
                      opacity: _fadeAnimation,
                      child: PageView.builder(
                        controller: _pageController,
                        onPageChanged: _onPageChanged,
                        itemCount: _storyPages.length,
                        itemBuilder: (context, index) {
                          return _buildStoryPage(_storyPages[index]);
                        },
                      ),
                    ),
                  ),

                  // 页面指示器
                  _buildPageIndicator(),

                  // 底部按钮
                  Padding(
                    padding: const EdgeInsets.all(24.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // 上一页按钮
                        IconButton(
                          onPressed: _isLoading
                              ? null
                              : (_currentPage > 0
                                  ? () {
                                      _pageController.previousPage(
                                        duration: const Duration(milliseconds: 400),
                                        curve: Curves.easeInOut,
                                      );
                                    }
                                  : null),
                          icon: Icon(
                            Icons.chevron_left,
                            size: 32,
                            color: _currentPage > 0
                                ? Colors.white
                                : Colors.white.withValues(alpha: 0.3),
                          ),
                        ),

                        // 开始按钮或下一页指示
                        if (_currentPage == _storyPages.length - 1)
                          ElevatedButton(
                            onPressed: _isLoading ? null : _startGame,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xffd49d6a),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 48,
                                vertical: 16,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                            child: _isLoading
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text(
                                    '开始旅程',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 4,
                                    ),
                                  ),
                          )
                        else
                          IconButton(
                            onPressed: _isLoading ? null : _nextPage,
                            icon: const Icon(
                              Icons.chevron_right,
                              size: 32,
                              color: Colors.white,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStoryPage(StoryPageData page) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: constraints.maxHeight,
            ),
            child: IntrinsicHeight(
              child: Column(
                children: [
                  const SizedBox(height: 40),

                  // 主图标
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 600),
                    width: 140,
                    height: 140,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          page.color.withValues(alpha: 0.8),
                          page.color,
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: page.color.withValues(alpha: 0.5),
                          blurRadius: 40,
                          spreadRadius: 10,
                        ),
                      ],
                    ),
                    child: Icon(
                      page.icon,
                      size: 70,
                      color: Colors.white,
                    ),
                  ),

                  const SizedBox(height: 32),

                  // 标题
                  Text(
                    page.title,
                    style: const TextStyle(
                      fontSize: 40,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                      letterSpacing: 8,
                    ),
                  ),

                  const SizedBox(height: 8),

                  // 副标题
                  Text(
                    page.subtitle,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: page.color,
                      letterSpacing: 4,
                    ),
                  ),

                  const SizedBox(height: 24),

                  // 简介
                  Container(
                    padding: const EdgeInsets.all(16),
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      border: Border.all(color: page.color.withValues(alpha: 0.5)),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      page.description,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.white.withValues(alpha: 0.9),
                        height: 1.8,
                        letterSpacing: 1,
                      ),
                    ),
                  ),

                  const SizedBox(height: 32),

                  // 故事文本框
                  Container(
                    padding: const EdgeInsets.all(20),
                    margin: const EdgeInsets.symmetric(horizontal: 8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withValues(alpha: 0.5),
                          Colors.black.withValues(alpha: 0.3),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.1),
                      ),
                    ),
                    child: Column(
                      children: page.storyText.split('\n').map((line) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4.0),
                          child: Text(
                            line,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.white.withValues(alpha: 0.85),
                              height: 2,
                              letterSpacing: 1,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  ),

                  const Spacer(flex: 1),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildPageIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(
          _storyPages.length,
          (index) => AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.symmetric(horizontal: 4),
            width: _currentPage == index ? 24 : 8,
            height: 8,
            decoration: BoxDecoration(
              color: _currentPage == index
                  ? const Color(0xffd49d6a)
                  : Colors.white.withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildBackgroundStars() {
    return List.generate(
      20,
      (index) => Positioned(
        left: (index * 17.5) % 100,
        top: (index * 23.7) % 100,
        child: TweenAnimationBuilder<double>(
          duration: Duration(milliseconds: 1500 + (index * 200)),
          tween: Tween(begin: 0.3, end: 1.0),
          builder: (context, value, child) {
            return Opacity(
              opacity: value * 0.5,
              child: child,
            );
          },
          onEnd: () {
            // 可以添加循环动画逻辑
          },
          child: Icon(
            Icons.star,
            size: 8 + (index % 3) * 4,
            color: const Color(0xffd49d6a),
          ),
        ),
      ),
    );
  }
}

/// 故事页面数据模型
class StoryPageData {
  final IconData icon;
  final String title;
  final String subtitle;
  final String description;
  final String storyText;
  final Color color;

  StoryPageData({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.description,
    required this.storyText,
    required this.color,
  });
}
